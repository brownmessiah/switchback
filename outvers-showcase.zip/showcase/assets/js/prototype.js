/* ============================================================================
   Outvers showcase — prototype navigation + micro-interactions
   Plain ES5-ish vanilla JS. No modules, no fetch, no build. file:// safe.
   ============================================================================ */
(function () {
  "use strict";

  /* ---- Flow definitions (screen order per journey) --------------------- */
  var FLOWS = {
    customer: ["home", "search", "collection", "pdp", "checkout", "checkout-pay", "confirmation", "dashboard"],
    vendor:   ["v-onboarding", "v-dashboard", "v-listings", "v-builder", "v-availability", "v-booking", "v-payouts"],
    admin:    ["a-dashboard", "a-queue", "a-kyc", "a-analytics"]
  };
  var LABELS = {
    home: "Home", search: "Search", collection: "Collection", pdp: "Experience",
    checkout: "Checkout", "checkout-pay": "Payment", confirmation: "Confirmed", dashboard: "Dashboard",
    "v-onboarding": "Onboarding", "v-dashboard": "Dashboard", "v-listings": "Listings",
    "v-builder": "Builder", "v-availability": "Availability", "v-booking": "Booking", "v-payouts": "Payouts",
    "a-dashboard": "Command center", "a-queue": "Money queue", "a-kyc": "KYC review", "a-analytics": "Analytics"
  };
  var lastScreen = { customer: "home", vendor: "v-onboarding", admin: "a-dashboard" };

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $all(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  function flowOf(screenId) {
    for (var f in FLOWS) { if (FLOWS[f].indexOf(screenId) !== -1) return f; }
    return null;
  }

  /* ---- View (top-level tab) switching ---------------------------------- */
  function showView(view) {
    $all(".view").forEach(function (v) { v.classList.toggle("is-active", v.getAttribute("data-view") === view); });
    $all(".tab").forEach(function (t) { t.classList.toggle("is-active", t.getAttribute("data-view") === view); });
    if (FLOWS[view]) showScreen(lastScreen[view] || FLOWS[view][0], true);
    window.scrollTo({ top: 0, behavior: "auto" });
  }

  /* ---- Screen (within-flow) switching ---------------------------------- */
  function showScreen(screenId, keepView) {
    var flow = flowOf(screenId);
    if (!flow) return;
    lastScreen[flow] = screenId;
    if (!keepView) showView(flow);

    var idx = FLOWS[flow].indexOf(screenId);
    var viewEl = $('.view[data-view="' + flow + '"]');
    if (!viewEl) return;

    $all(".screen", viewEl).forEach(function (s) {
      s.classList.toggle("is-active", s.getAttribute("data-screen") === screenId);
    });

    // update step dots
    var bar = $('[data-flowbar="' + flow + '"]', viewEl);
    if (bar) {
      $all(".flowstep", bar).forEach(function (step, i) {
        step.classList.toggle("is-active", i === idx);
        step.classList.toggle("is-done", i < idx);
      });
      $all(".flowstep__line", bar).forEach(function (line, i) {
        line.classList.toggle("is-filled", i < idx);
      });
      var back = $('[data-flow-nav="back"]', bar), next = $('[data-flow-nav="next"]', bar);
      if (back) back.toggleAttribute("disabled", idx === 0);
      if (next) {
        var atEnd = idx === FLOWS[flow].length - 1;
        next.toggleAttribute("disabled", atEnd);
        next.innerHTML = atEnd ? "End of flow" : ("Next &rsaquo;");
      }
    }
    // scroll the stage viewport back to top
    var active = $('.screen.is-active .browser__viewport', viewEl);
    if (active) active.scrollTop = 0;
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function flowNav(dir) {
    var view = $(".view.is-active");
    if (!view) return;
    var flow = view.getAttribute("data-view");
    if (!FLOWS[flow]) return;
    var cur = lastScreen[flow];
    var idx = FLOWS[flow].indexOf(cur);
    var nidx = Math.min(Math.max(idx + (dir === "next" ? 1 : -1), 0), FLOWS[flow].length - 1);
    showScreen(FLOWS[flow][nidx], true);
  }

  /* ---- Render the flow step bars --------------------------------------- */
  function buildFlowBars() {
    $all("[data-flowbar]").forEach(function (bar) {
      var flow = bar.getAttribute("data-flowbar");
      var steps = $(".flowsteps", bar);
      if (!steps) return;
      FLOWS[flow].forEach(function (id, i) {
        if (i > 0) {
          var line = document.createElement("span");
          line.className = "flowstep__line";
          steps.appendChild(line);
        }
        var step = document.createElement("div");
        step.className = "flowstep";
        var btn = document.createElement("button");
        btn.className = "flowstep__dot";
        btn.setAttribute("data-goto", id);
        btn.innerHTML = '<span class="n">' + (i + 1) + '</span><span>' + (LABELS[id] || id) + '</span>';
        step.appendChild(btn);
        steps.appendChild(step);
      });
    });
  }

  /* ---- Modal / confirm-money dialog (A4) ------------------------------- */
  var lastFocused = null;
  function openModal(id) {
    var m = document.getElementById(id);
    if (!m) return;
    lastFocused = document.activeElement;
    m.classList.add("is-open");
    var def = $("[data-default-focus]", m) || $("button, [href], input", m);
    if (def) def.focus();
    document.addEventListener("keydown", modalKeys);
  }
  function closeModal(m) {
    if (!m) m = $(".modal.is-open");
    if (!m) return;
    m.classList.remove("is-open");
    document.removeEventListener("keydown", modalKeys);
    if (lastFocused && lastFocused.focus) lastFocused.focus();
  }
  function modalKeys(e) {
    var m = $(".modal.is-open");
    if (!m) return;
    if (e.key === "Escape") { e.preventDefault(); closeModal(m); return; }
    if (e.key === "Tab") {
      var f = $all('button, [href], input, [tabindex]:not([tabindex="-1"])', m).filter(function (el) { return !el.disabled && el.offsetParent !== null; });
      if (!f.length) return;
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  }
  // confirm action → flash a success toast row, then close
  function confirmMoney(m) {
    var done = $("[data-confirm-done]", m);
    if (done) { done.hidden = false; }
    setTimeout(function () { closeModal(m); if (done) done.hidden = true; }, 1100);
  }

  /* ---- Before/After slider --------------------------------------------- */
  function wireBA() {
    $all("[data-ba]").forEach(function (range) {
      var stage = range.closest(".ba-stage");
      if (!stage) return;
      function apply() {
        var pct = range.value + "%";
        stage.style.setProperty("--pct", pct);
        var after = $(".ba-after", stage);
        var div = $(".ba-divider", stage);
        if (after) after.style.clipPath = "inset(0 " + (100 - range.value) + "% 0 0)";
        if (div) div.style.left = pct;
      }
      range.addEventListener("input", apply);
      apply();
    });
  }

  /* ---- Generic toggle groups (calendar/manifest, etc.) ----------------- */
  function wireToggles() {
    $all("[data-toggle-group]").forEach(function (group) {
      $all("[data-toggle-target]", group).forEach(function (btn) {
        btn.addEventListener("click", function () {
          var target = btn.getAttribute("data-toggle-target");
          $all("[data-toggle-target]", group).forEach(function (b) { b.classList.toggle("is-active", b === btn); });
          var scope = group.getAttribute("data-toggle-scope") ? document.querySelector(group.getAttribute("data-toggle-scope")) : group.parentNode;
          $all("[data-toggle-panel]", scope).forEach(function (p) {
            p.hidden = p.getAttribute("data-toggle-panel") !== target;
          });
        });
      });
    });
  }

  /* ---- Radio-card groups ----------------------------------------------- */
  function wireRadioGroups() {
    $all("[data-radio-group]").forEach(function (group) {
      $all(".radio-card", group).forEach(function (card) {
        card.addEventListener("click", function () {
          $all(".radio-card", group).forEach(function (c) {
            c.classList.toggle("is-selected", c === card);
            c.setAttribute("aria-checked", c === card ? "true" : "false");
          });
          // optional: drive a Pay button label
          var payTarget = group.getAttribute("data-pay-target");
          var amt = card.getAttribute("data-pay-amount");
          if (payTarget && amt) { var t = document.querySelector(payTarget); if (t) t.textContent = "Pay " + amt; }
        });
      });
    });
  }

  /* ---- Filter chips (visual only) -------------------------------------- */
  function wireChips() {
    $all("[data-chips]").forEach(function (group) {
      $all(".chip", group).forEach(function (chip) {
        chip.addEventListener("click", function () {
          if (group.getAttribute("data-chips") === "multi") { chip.classList.toggle("is-active"); }
          else { $all(".chip", group).forEach(function (c) { c.classList.toggle("is-active", c === chip); }); }
        });
      });
    });
  }

  /* ---- Live booking calculator (PDP + checkout) ------------------------ */
  function inr(n) { return "₹" + Math.round(n).toLocaleString("en-IN"); }
  function wireCalc() {
    $all("[data-calc]").forEach(function (root) {
      var qtyEl = $("[data-out=qty]", root);
      var rate = { a: +root.getAttribute("data-rate-12"), b: +root.getAttribute("data-rate-35"), c: +root.getAttribute("data-rate-6") };
      var permit = +(root.getAttribute("data-permit") || 0);
      var advancePct = +(root.getAttribute("data-advance-pct") || 25);
      var qty = +(root.getAttribute("data-qty") || 2);
      function bracket(q) { return q <= 2 ? "1–2" : (q <= 5 ? "3–5" : "6+"); }
      function rateFor(q) { return q <= 2 ? rate.a : (q <= 5 ? rate.b : rate.c); }
      function render(animate) {
        var r = rateFor(qty), sub = r * qty, perm = permit * qty, total = sub + perm;
        var adv = Math.round(total * advancePct / 100), bal = total - adv;
        function set(name, val) { $all("[data-out=" + name + "]", root).forEach(function (e) { e.textContent = val; if (animate) { e.classList.remove("reveal"); void e.offsetWidth; e.classList.add("reveal"); } }); }
        set("qty", qty); set("bracket", bracket(qty)); set("rate", inr(r));
        set("subtotal", inr(sub)); set("permit", inr(perm)); set("total", inr(total));
        set("advance", inr(adv)); set("balance", inr(bal));
        set("advance-pct", advancePct + "%"); set("balance-pct", (100 - advancePct) + "%");
        // highlight active bracket row
        $all("[data-bracket-row]", root).forEach(function (row) {
          row.classList.toggle("is-active", row.getAttribute("data-bracket-row") === bracket(qty));
        });
        // pay button on checkout
        var pb = $("[data-out=paybtn]", root); // optional
      }
      $all("[data-calc-inc]", root).forEach(function (b) { b.addEventListener("click", function () { qty = Math.min(qty + 1, 12); render(true); }); });
      $all("[data-calc-dec]", root).forEach(function (b) { b.addEventListener("click", function () { qty = Math.max(qty - 1, 1); render(true); }); });
      render(false);
    });
  }

  /* ---- Anchor-nav active state (visual) -------------------------------- */
  function wireAnchorNav() {
    $all(".anchornav").forEach(function (nav) {
      $all("a", nav).forEach(function (a) {
        a.addEventListener("click", function (e) {
          $all("a", nav).forEach(function (x) { x.classList.toggle("is-active", x === a); });
        });
      });
    });
  }

  /* ---- Theme toggle ---------------------------------------------------- */
  function toggleTheme() {
    document.documentElement.classList.toggle("dark");
    var t = $("[data-theme-toggle] .label");
    if (t) t.textContent = document.documentElement.classList.contains("dark") ? "Light" : "Dark";
  }

  /* ---- Global click delegation ----------------------------------------- */
  document.addEventListener("click", function (e) {
    var el = e.target.closest("[data-view],[data-goto],[data-flow-nav],[data-modal-open],[data-modal-close],[data-modal-confirm],[data-theme-toggle]");
    if (!el) return;
    if (el.hasAttribute("data-view")) { e.preventDefault(); showView(el.getAttribute("data-view")); }
    else if (el.hasAttribute("data-goto")) { e.preventDefault(); showScreen(el.getAttribute("data-goto")); }
    else if (el.hasAttribute("data-flow-nav")) { e.preventDefault(); flowNav(el.getAttribute("data-flow-nav")); }
    else if (el.hasAttribute("data-modal-open")) { e.preventDefault(); openModal(el.getAttribute("data-modal-open")); }
    else if (el.hasAttribute("data-modal-confirm")) { e.preventDefault(); confirmMoney(el.closest(".modal")); }
    else if (el.hasAttribute("data-modal-close")) { e.preventDefault(); closeModal(el.closest(".modal")); }
    else if (el.hasAttribute("data-theme-toggle")) { e.preventDefault(); toggleTheme(); }
  });
  // click on modal overlay closes
  document.addEventListener("click", function (e) {
    if (e.target.classList && e.target.classList.contains("modal__overlay")) closeModal(e.target.closest(".modal"));
  });

  /* ---- Boot ------------------------------------------------------------ */
  document.addEventListener("DOMContentLoaded", function () {
    buildFlowBars();
    wireBA();
    wireToggles();
    wireRadioGroups();
    wireChips();
    wireCalc();
    wireAnchorNav();
    // deep-link via hash (#customer/pdp) for convenience
    var hash = (location.hash || "").replace("#", "");
    if (hash) {
      var parts = hash.split("/");
      if (FLOWS[parts[0]] && parts[1]) showScreen(parts[1]);
      else if (parts[0]) showView(parts[0]);
      else showView("overview");
    } else {
      showView("overview");
    }
  });

  // expose for inline handlers if ever needed
  window.OV = { showView: showView, showScreen: showScreen, openModal: openModal, closeModal: closeModal };
})();
